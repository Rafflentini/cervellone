/**
 * lib/rate-limiter.ts — SEC-003 fix
 * Sliding window rate limiter. In-memory, no external deps.
 * Serverless-safe: no setInterval, cleanup inline.
 */

const buckets = new Map<string, number[]>()

export function rateLimit(key: string, windowMs = 60_000, max = 5): boolean {
  const now = Date.now()
  const timestamps = buckets.get(key)?.filter(t => now - t < windowMs) || []
  if (timestamps.length >= max) return false
  timestamps.push(now)
  buckets.set(key, timestamps)

  // Inline cleanup: remove stale keys (no setInterval needed on serverless)
  if (buckets.size > 100) {
    for (const [k, ts] of buckets) {
      if (ts.every(t => now - t > windowMs * 2)) buckets.delete(k)
    }
  }

  return true
}
