/**
 * lib/types.ts — Interfacce TypeScript condivise
 * Riduce uso di `any` nel codebase.
 */

// ── Telegram ──

export interface TelegramMessage {
  message_id: number
  chat: { id: number; type: string }
  text?: string
  caption?: string
  photo?: Array<{ file_id: string; width: number; height: number }>
  document?: { file_id: string; file_name?: string; file_size?: number; mime_type?: string }
  voice?: { file_id: string; duration: number }
  audio?: { file_id: string }
  video?: { file_id: string; thumb?: { file_id: string }; thumbnail?: { file_id: string } }
  sticker?: { file_id: string }
  animation?: { file_id: string }
  location?: { latitude: number; longitude: number }
  contact?: { phone_number?: string; first_name: string }
  media_group_id?: string
}

export interface TelegramWebhookBody {
  message?: TelegramMessage
  edited_message?: TelegramMessage
  callback_query?: unknown
}

// ── Tool Results ──

export interface ToolResultBlock {
  type: 'tool_result'
  tool_use_id: string
  content: string
}

// ── Memory ──

export interface MemorySearchResult {
  content: string
  message_role: string
  similarity: number
}

// ── File Processing ──

export interface DownloadedFile {
  buffer: ArrayBuffer
  fileName: string
  mimeType: string
}

export interface ContentBlock {
  type: 'text' | 'image' | 'document'
  text?: string
  source?: {
    type: 'base64'
    media_type: string
    data: string
  }
}
