/**
 * telegram-helpers.ts — Utilities specifiche Telegram
 * 
 * Download file, invio messaggi, typing, content blocks.
 * Estratto dal route per pulizia — logica invariata.
 */

import { supabase } from './supabase'

const TELEGRAM_API = 'https://api.telegram.org/bot'

/**
 * Fetch con timeout. Usato per TUTTE le chiamate HTTP in telegram-helpers.
 */
async function fetchWithTimeout(url: string, options: RequestInit = {}, timeoutMs = 30_000): Promise<Response> {
  const controller = new AbortController()
  const timeout = setTimeout(() => controller.abort(), timeoutMs)
  try {
    const res = await fetch(url, { ...options, signal: controller.signal })
    return res
  } finally {
    clearTimeout(timeout)
  }
}

export async function sendTelegramMessage(chatId: number, text: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN
  if (!token) return
  const MAX_LEN = 4000
  const chunks: string[] = []
  if (text.length <= MAX_LEN) {
    chunks.push(text)
  } else {
    let remaining = text
    while (remaining.length > 0) {
      if (remaining.length <= MAX_LEN) { chunks.push(remaining); break }
      let cutAt = remaining.lastIndexOf('\n\n', MAX_LEN)
      if (cutAt < 500) cutAt = remaining.lastIndexOf('\n', MAX_LEN)
      if (cutAt < 500) cutAt = MAX_LEN
      chunks.push(remaining.slice(0, cutAt))
      remaining = remaining.slice(cutAt).trimStart()
    }
  }
  for (const chunk of chunks) {
    // INT-002: Try with Markdown parse_mode, fallback to plain text
    const res = await fetchWithTimeout(`${TELEGRAM_API}${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: chunk, parse_mode: 'Markdown' }),
    }, 10_000)
    if (!res.ok) {
      // Markdown parse failed (unmatched * or _), retry without
      await fetchWithTimeout(`${TELEGRAM_API}${token}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: chatId, text: chunk }),
      }, 10_000)
    }
  }
}

export async function sendTyping(chatId: number) {
  const token = process.env.TELEGRAM_BOT_TOKEN
  if (!token) return
  await fetchWithTimeout(`${TELEGRAM_API}${token}/sendChatAction`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, action: 'typing' }),
  }, 5_000).catch(() => {})
}

export async function downloadTelegramFile(fileId: string): Promise<{ buffer: ArrayBuffer; fileName: string; mimeType: string } | null> {
  const token = process.env.TELEGRAM_BOT_TOKEN
  if (!token) return null
  // Timeout 15s per getFile API, 60s per download (file grandi fino a 20MB)
  const fileRes = await fetchWithTimeout(`${TELEGRAM_API}${token}/getFile`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file_id: fileId }),
  }, 15_000)
  const fileData = await fileRes.json()
  const filePath = fileData.result?.file_path
  if (!filePath) return null
  const fileName = filePath.split('/').pop() || 'file'
  const ext = fileName.split('.').pop()?.toLowerCase() || ''
  const mimeMap: Record<string, string> = {
    pdf: 'application/pdf',
    doc: 'application/msword',
    docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    odt: 'application/vnd.oasis.opendocument.text',
    xls: 'application/vnd.ms-excel',
    xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ods: 'application/vnd.oasis.opendocument.spreadsheet',
    csv: 'text/csv',
    pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
    jpg: 'image/jpeg', jpeg: 'image/jpeg',
    png: 'image/png', gif: 'image/gif', webp: 'image/webp',
    tiff: 'image/tiff', tif: 'image/tiff',
    dwg: 'application/acad', dxf: 'application/dxf',
    txt: 'text/plain', md: 'text/markdown',
    json: 'application/json', xml: 'application/xml',
    html: 'text/html',
    zip: 'application/zip', rar: 'application/x-rar-compressed',
  }
  const res = await fetchWithTimeout(
    `https://api.telegram.org/file/bot${token}/${filePath}`,
    {}, 60_000 // 60s per file grandi
  )
  if (!res.ok) return null
  return { buffer: await res.arrayBuffer(), fileName, mimeType: mimeMap[ext] || 'application/octet-stream' }
}

export async function transcribeAudio(fileId: string): Promise<string> {
  const token = process.env.TELEGRAM_BOT_TOKEN
  if (!token) return ''
  // Timeout 15s getFile, 60s download audio, 60s Whisper transcription
  const fileRes = await fetchWithTimeout(`${TELEGRAM_API}${token}/getFile`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ file_id: fileId }),
  }, 15_000)
  const fileData = await fileRes.json()
  const filePath = fileData.result?.file_path
  if (!filePath) return ''
  const audioRes = await fetchWithTimeout(
    `https://api.telegram.org/file/bot${token}/${filePath}`,
    {}, 60_000
  )
  const audioBuffer = await audioRes.arrayBuffer()
  const formData = new FormData()
  formData.append('file', new Blob([audioBuffer], { type: 'audio/ogg' }), 'voice.ogg')
  formData.append('model', 'whisper-1')
  formData.append('language', 'it')
  const whisperRes = await fetchWithTimeout('https://api.openai.com/v1/audio/transcriptions', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${process.env.OPENAI_API_KEY}` },
    body: formData,
  }, 60_000) // Whisper può impiegare fino a 60s per audio lunghi
  if (!whisperRes.ok) return ''
  const data = await whisperRes.json()
  return data.text || ''
}

/**
 * Converte un file scaricato in content blocks per Claude.
 * Gestisce PDF, immagini, Word, ODS (con auto-import prezziario), Excel, CSV, testo.
 */
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function buildContentBlocks(fileData: { buffer: ArrayBuffer; fileName: string; mimeType: string }): Promise<any[]> {
  const { buffer, fileName, mimeType } = fileData
  const base64 = Buffer.from(buffer).toString('base64')

  // PDF → document block nativo
  if (mimeType === 'application/pdf') {
    return [{ type: 'document', source: { type: 'base64', media_type: mimeType, data: base64 } }]
  }

  // Immagini → image block nativo
  if (mimeType.startsWith('image/')) {
    return [{ type: 'image', source: { type: 'base64', media_type: mimeType, data: base64 } }]
  }

  // Word → estrai testo
  if (mimeType.includes('word') || mimeType === 'application/msword') {
    try {
      const mammoth = await import('mammoth')
      const result = await mammoth.extractRawText({ arrayBuffer: buffer })
      if (result.value?.length > 50) {
        return [{ type: 'text', text: `[File Word: ${fileName}]\n\n${result.value}` }]
      }
    } catch { /* fallthrough */ }
  }

  // ODS — con auto-import prezziario
  if (fileName.endsWith('.ods')) {
    return await parseOds(buffer, fileName)
  }

  // Excel
  if (fileName.endsWith('.xlsx') || fileName.endsWith('.xls')) {
    try {
      const JSZip = (await import('jszip')).default
      const zip = await JSZip.loadAsync(Buffer.from(buffer))
      const shared = await zip.file('xl/sharedStrings.xml')?.async('string')
      if (shared) {
        const texts: string[] = []
        const re = /<t[^>]*>([\s\S]*?)<\/t>/g
        let m
        while ((m = re.exec(shared)) !== null) texts.push(m[1].trim())
        if (texts.length > 0) {
          return [{ type: 'text', text: `[File Excel: ${fileName}]\n\n${texts.join(' | ').slice(0, 100000)}` }]
        }
      }
    } catch { /* fallthrough */ }
  }

  // CSV/TXT
  if (fileName.endsWith('.csv') || fileName.endsWith('.txt')) {
    const text = Buffer.from(buffer).toString('utf-8')
    if (text.length > 50) {
      return [{ type: 'text', text: `[File ${fileName}]\n\n${text.slice(0, 100000)}` }]
    }
  }

  // Fallback: tenta testo
  try {
    const text = Buffer.from(buffer).toString('utf-8')
    const printable = text.replace(/[^\x20-\x7E\r\n\t\xC0-\xFF]/g, '')
    if (printable.length > text.length * 0.5 && text.length > 50) {
      return [{ type: 'text', text: `[File: ${fileName}]\n\n${text.slice(0, 100000)}` }]
    }
  } catch { /* ignore */ }

  return [{ type: 'text', text: `[File binario: ${fileName}, ${(buffer.byteLength / 1024).toFixed(0)} KB, tipo: ${mimeType}] — Formato non leggibile come testo.` }]
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function parseOds(buffer: ArrayBuffer, fileName: string): Promise<any[]> {
  try {
    const JSZip = (await import('jszip')).default
    const zip = await JSZip.loadAsync(Buffer.from(buffer))
    const xml = await zip.file('content.xml')?.async('string')
    if (!xml) return [{ type: 'text', text: `[File ODS: ${fileName}] — Impossibile leggere contenuto.` }]

    const rows: string[] = []
    const rowRe = /<table:table-row[^>]*>([\s\S]*?)<\/table:table-row>/g
    let rm
    while ((rm = rowRe.exec(xml)) !== null) {
      const cells: string[] = []
      const cellRe = /<table:table-cell([^>]*)>([\s\S]*?)<\/table:table-cell>/g
      let cm
      while ((cm = cellRe.exec(rm[1])) !== null) {
        const txt = (cm[2] || '').replace(/<[^>]+>/g, '').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/&apos;/g, "'").trim()
        if (txt) cells.push(txt)
      }
      if (cells.length >= 2) rows.push(cells.join(' | '))
    }

    // Auto-detect prezziario
    const allText = rows.slice(0, 100).join('\n')
    const isPrezziario = /prezz/i.test(fileName) || /[A-Z]{2,5}\d{2}_/i.test(allText) || (rows.length > 1000 && /\d+[.,]\d{2}/.test(allText))

    if (isPrezziario && rows.length > 100) {
      return await importPrezziario(rows, fileName, allText)
    }

    const text = rows.slice(0, 2000).join('\n')
    if (text.length > 50) {
      return [{ type: 'text', text: `[File ODS: ${fileName} — ${rows.length} righe]\n\n${text.slice(0, 80000)}` }]
    }
  } catch (err) {
    console.error('ODS parse error:', err)
  }
  return [{ type: 'text', text: `[File ODS: ${fileName}] — Errore lettura.` }]
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function importPrezziario(rows: string[], fileName: string, headerText: string): Promise<any[]> {
  const regioneMatch = (fileName + ' ' + headerText).match(/basilicata|calabria|campania|puglia|sicilia|sardegna|lazio|toscana|lombardia|piemonte|veneto|emilia|liguria|marche|umbria|abruzzo|molise|friuli|trentino|valle/i)
  const regione = regioneMatch ? regioneMatch[0].toLowerCase() : 'basilicata'
  const annoMatch = (fileName + ' ' + headerText).match(/20\d{2}/)
  const anno = annoMatch ? parseInt(annoMatch[0]) : new Date().getFullYear()

  const voci: { codice_voce: string; descrizione: string; unita_misura: string; prezzo: number }[] = []
  for (const row of rows) {
    const cells = row.split(' | ')
    if (cells.length < 3) continue
    const codice = cells[0]
    if (!/^[A-Z]{2,5}\d{2}_/.test(codice)) continue
    const descrizione = cells[1]
    if (!descrizione || descrizione.length < 5) continue
    let prezzo = 0
    let um = ''
    for (let i = cells.length - 1; i >= 2; i--) {
      if (cells[i].includes('%')) continue
      const num = parseFloat(cells[i].replace(',', '.'))
      if (!isNaN(num) && num > 0 && num < 999999) { prezzo = num; break }
    }
    if (cells.length > 2) um = cells[2].toLowerCase().slice(0, 20)
    if (prezzo > 0) voci.push({ codice_voce: codice, descrizione: descrizione.slice(0, 500), unita_misura: um, prezzo: Math.round(prezzo * 100) / 100 })
  }

  if (voci.length > 100) {
    await supabase.from('prezziario').delete().eq('regione', regione).eq('anno', anno)
    let salvate = 0
    for (let i = 0; i < voci.length; i += 500) {
      const batch = voci.slice(i, i + 500).map(v => ({ regione, anno, ...v, fonte: `Prezziario ${regione} ${anno} (ODS)` }))
      const { error } = await supabase.from('prezziario').insert(batch)
      if (!error) salvate += batch.length
    }
    return [{ type: 'text', text: `[PREZZIARIO IMPORTATO] ✅ ${regione.toUpperCase()} ${anno}: ${salvate} voci salvate nel database.` }]
  }

  return [{ type: 'text', text: `[File ODS prezziario: ${fileName}] — Solo ${voci.length} voci valide trovate (serve minimo 100).` }]
}
